
import AudioSource from '../models/AudioSource.js';
import { connectDB, closeDB } from '../config/db.js';
import { MOCK_AUDIO_SOURCES } from '../../ProxiSpeak-frontend/src/data/mockAudioData.js';

async function seedAudioSources() {
  try {
    await connectDB();

    if (!Array.isArray(MOCK_AUDIO_SOURCES)) {
      throw new Error('MOCK_AUDIO_SOURCES dataset is not available.');
    }

    const validSources = MOCK_AUDIO_SOURCES.filter((source) => {
      return (
        source &&
        typeof source.id === 'string' &&
        source.id.trim() &&
        typeof source.title === 'string' &&
        source.coordinates &&
        Number.isFinite(source.coordinates.latitude) &&
        Number.isFinite(source.coordinates.longitude)
      );
    });

    if (validSources.length === 0) {
      throw new Error('No valid place records found in the dataset.');
    }

    const operations = validSources.map((source) => ({
      updateOne: {
        filter: { id: source.id },
        update: {
          $set: {
            ...source,
            isPlace: true,
            audioType: 'heritage',
            approvalStatus: 'approved',
            uploadedBy: null
          }
        },
        upsert: true
      }
    }));

    const result = await AudioSource.bulkWrite(operations);

    console.log('\n================================');
    console.log('India Place Catalogue Seeded!');
    console.log('================================');
    console.log('Valid places:', validSources.length);
    console.log('Inserted:', result.upsertedCount);
    console.log('Updated:', result.modifiedCount);
    console.log('Matched:', result.matchedCount);
    console.log('================================\n');

  } catch (error) {
    console.error('Seeding failed:', error);
    process.exitCode = 1;
  } finally {
    await closeDB();
  }
}

seedAudioSources();
